Here are two VB6 modules you can use for creating and reading INI
files. You may like to save then in your Templates\Modules folder
for easy recall.

Those not confident with using the API call:

Private Declare Function GetPrivateProfileString Lib "kernel32"
Alias "GetPrivateProfileStringA" (ByVal lpApplicationName As String,
ByVal lpKeyName As Any, ByVal lpDefault As String, ByVal
lpReturnedString As String, ByVal nSize As Long, ByVal lpFileName As
String) As Long

and:

Private Declare Function WritePrivateProfileString Lib "kernel32"
Alias "WritePrivateProfileStringA" (ByVal lpApplicationName As
String, ByVal lpKeyName As Any, ByVal lpString As Any, ByVal
lpFileName As String) As Long

will find these modules allow you to see exactly what is happening
and give you flexibility to alter the code for specific needs.

The sample program demonstrates how information is recorded to and
retrieved from the ini file, allowing seamless continuation on
subsequent starts of the program. Whatever fields are displayed on
the form, will appear next time it is run.

You are free to customize this code for you own need. There is no
copyright. Contact me at any time. Regards Bernie Madigan.
bernie@testrun.cjb.net
